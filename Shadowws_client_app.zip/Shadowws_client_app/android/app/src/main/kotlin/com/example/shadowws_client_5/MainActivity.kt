package com.example.shadowws_client_5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
